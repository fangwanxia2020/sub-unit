/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'tyicon\'">' + entity + '</span>' + html;
	}
	var icons = {
		'anticon-guanbi': '&#xe93b;',
		'anticon-money': '&#xe93a;',
		'anticon-alipay': '&#xe938;',
		'anticon-wechat': '&#xe939;',
		'anticon-bidding': '&#xe927;',
		'anticon-organization': '&#xe928;',
		'anticon-examine': '&#xe929;',
		'anticon-platformManage': '&#xe92a;',
		'anticon-addUser': '&#xe92b;',
		'anticon-acceptance': '&#xe92c;',
		'anticon-view': '&#xe92d;',
		'anticon-preview': '&#xe92e;',
		'anticon-survey': '&#xe92f;',
		'anticon-settings': '&#xe930;',
		'anticon-platformUser': '&#xe931;',
		'anticon-userManage': '&#xe932;',
		'anticon-basics': '&#xe933;',
		'anticon-item': '&#xe934;',
		'anticon-hamburger': '&#xe901;',
		'anticon-purchaser': '&#xe935;',
		'anticon-notice': '&#xe936;',
		'anticon-myProject': '&#xe937;',
		'anticon-download': '&#xe91b;',
		'anticon-logout': '&#xe91d;',
		'anticon-analysis': '&#xe91e;',
		'anticon-form': '&#xe91f;',
		'anticon-designer': '&#xe920;',
		'anticon-table': '&#xe921;',
		'anticon-code': '&#xe922;',
		'anticon-notes': '&#xe923;',
		'anticon-structure': '&#xe924;',
		'anticon-pen': '&#xe925;',
		'anticon-standard': '&#xe926;',
		'anticon-home': '&#xe904;',
		'anticon-components': '&#xe91c;',
		'anticon-slider': '&#xe907;',
		'anticon-card': '&#xe908;',
		'anticon-tab': '&#xe909;',
		'anticon-grid': '&#xe90a;',
		'anticon-cascader': '&#xe90b;',
		'anticon-switch': '&#xe90c;',
		'anticon-color': '&#xe90d;',
		'anticon-star': '&#xe90e;',
		'anticon-number': '&#xe90f;',
		'anticon-edit': '&#xe910;',
		'anticon-image': '&#xe911;',
		'anticon-date': '&#xe912;',
		'anticon-time': '&#xe913;',
		'anticon-select': '&#xe914;',
		'anticon-checkbox': '&#xe915;',
		'anticon-radio': '&#xe916;',
		'anticon-textarea': '&#xe917;',
		'anticon-passwordInput': '&#xe918;',
		'anticon-text': '&#xe919;',
		'anticon-input': '&#xe91a;',
		'anticon-skin': '&#xe900;',
		'anticon-openEye': '&#xe902;',
		'anticon-closeEye': '&#xe903;',
		'anticon-username': '&#xe905;',
		'anticon-password': '&#xe906;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/anticon-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
